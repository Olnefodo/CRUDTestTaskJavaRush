package com.oleksandr.dao.impl;

import java.util.List;
import java.util.logging.Logger;

import com.oleksandr.dao.UserDao;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.oleksandr.model.User;

@Repository
public class UserDaoImpl implements UserDao {
    Logger log = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
	@Autowired
	private SessionFactory session;
	
	@Override
	public void add(User user) {
		session.getCurrentSession().save(user);
	}

	@Override
	public void edit(User user) {
            session.getCurrentSession().update(user);
	}

	@Override
	public void delete(int userId) {

		Session s = session.getCurrentSession();
		User user = getUser(userId);
		if (user != null)
			s.delete(user);
	}

	@Override
	public User getUser(int userId) {
        return (User) session.getCurrentSession().get(User.class, userId);
	}

	@Override
	public List getAllUsers() {
		return session.getCurrentSession().createQuery("from User").list();
	}

}
