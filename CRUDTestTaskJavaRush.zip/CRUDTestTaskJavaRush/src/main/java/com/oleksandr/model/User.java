package com.oleksandr.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;

@Entity
public class User {
	@Id
	@Column
	@GeneratedValue(strategy=GenerationType.AUTO) //for autonumber
	private int userId;
	@Column
	private String firstname;
	@Column
	private int age;
    @Column
    private boolean isAdmin;
    @Column
    private Date timeStamp;
	public User(){
		this.timeStamp = new java.sql.Timestamp(new Date().getTime());
	}
	public User(int userId, String firstname, int age, boolean isAdmin) {
		super();
		this.userId = userId;
		this.firstname = firstname;
		this.age = age;
        this.isAdmin = isAdmin;
	}
    public Date getTimeStamp(){return this.timeStamp;}
    public void setTimeStamp(){this.timeStamp = new java.sql.Timestamp(new Date().getTime());}
    public void setIsAdmin(boolean isAdmin){this.isAdmin = isAdmin;}
    public boolean getIsAdmin(){return this.isAdmin;}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
}
