package com.oleksandr.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.support.PagedListHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.oleksandr.model.User;
import com.oleksandr.service.UserService;


import javax.servlet.http.HttpServletRequest;

@Controller
public class UserController {
	@Autowired
	private UserService userService;
    private PagedListHolder<User> pagedListHolder;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String setupForm(HttpServletRequest request, Map<String, Object> map){
		User user = new User();
        pagedListHolder = new PagedListHolder(userService.getAllUsers());
        int page = ServletRequestUtils.getIntParameter(request, "p", 0);
        pagedListHolder.setPage(page);
        pagedListHolder.setPageSize(4);
        map.put("user", user);
        map.put("pagedListHolder", pagedListHolder);
		return "user";
	}
	@RequestMapping(value="/user.do", method=RequestMethod.POST)
	public String doActions(HttpServletRequest request, @ModelAttribute User user, BindingResult result, @RequestParam String action, Map<String, Object> map){
		boolean isNotNull = false;
        for (User user1 : pagedListHolder.getPageList()){
            if (user1.getUserId() == user.getUserId()) {
                isNotNull = true;
                break;
            }
        }
        //if (action.equalsIgnoreCase("search"))
            //
        User userResult = new User();
		switch(action.toLowerCase()){
		case "add":
			userService.add(user);
			userResult = user;
			break;
		case "edit":
                if (isNotNull) {
                    userService.edit(user);
                    userResult = user;
                }
			break;
		case "delete":
			userService.delete(user.getUserId());
			userResult = new User();
			break;
		case "search":
            if(isNotNull) {
                User searchedUser = userService.getUser(user.getUserId());
                userResult = searchedUser != null ? searchedUser : new User();
                List list = new ArrayList();
                list.add(userResult);
                pagedListHolder = new PagedListHolder<>(list);
            }
			break;
		}


        if (!action.equalsIgnoreCase("search"))
            pagedListHolder = new PagedListHolder(userService.getAllUsers());
        int page = ServletRequestUtils.getIntParameter(request, "p", 0);
        pagedListHolder.setPage(page);
        pagedListHolder.setPageSize(4);

        map.put("user", userResult);
        map.put("pagedListHolder", pagedListHolder);
        pagedListHolder = new PagedListHolder(userService.getAllUsers());
		return "user";
    }
}
